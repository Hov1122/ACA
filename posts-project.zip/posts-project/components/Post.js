export const Post = ({ title, body } = {}) => {
  if (!title) return undefined
  const clone = document
      .querySelector(("#post-template"))
      .cloneNode(true);

  clone.content.querySelector('.post .title').innerHTML = title;
  clone.content.querySelector('.post .body').innerHTML = body;

  return clone.content;
};
