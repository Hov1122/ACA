export const Input = () => {
    const clone = document
        .querySelector(("#search-template"))
        .cloneNode(true);

    const input = clone.content.querySelector('.search-container');
    return input;
}
