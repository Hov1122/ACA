import { Post } from "./Post.js";

export const Posts = (data) => {
  const container = document.createElement("div");
  container.classList.add("posts-container");
  container.setAttribute("component-name", "posts");

  const df = new DocumentFragment();

  data.forEach((post) => {
    df.append(Post(post));
  });

  container.append(df);

  return container;
};
