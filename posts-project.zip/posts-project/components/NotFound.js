export const NotFound = () => {
    const nFoundContainer = document.createElement('div');
    const nf = document.createElement('span');
    nf.classList.add('error');
    nFoundContainer.classList.add('error-container');

    nf.innerHTML = 'Post not found';
    nFoundContainer.append(nf)

    return nFoundContainer
};
