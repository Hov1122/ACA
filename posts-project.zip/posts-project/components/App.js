import { fetchData } from "../helpers.js";
import { Posts } from "./Posts.js";
import { Input } from "./Input.js";
<<<<<<< HEAD

export const App = () => {
  const state = {
    posts: [],
    filteredPosts: [],
    inputValue: "",
  };

  const filterPosts = (ev) => {
    const temp = state.posts.filter((item) => {
      return item.title.includes(ev.target.value);
    });

    state.inputValue = ev.target.value;
    setFilteredPosts(temp);
=======
import { debounce } from "../helpers.js";
import { NotFound } from "./NotFound.js";

export const App = () => {

  function filter(e) {
    setFilteredPosts(state.posts.filter((post) => post.title.includes(e.target.value)));
    e.target.focus();
  }

  const state = {
    posts: [],
    filteredPosts: [],
>>>>>>> b38ff99 (posts-project)
  };

  window.state = state;

  const container = document.createElement("div");
<<<<<<< HEAD
  container.classList.add("main-container");
  container.setAttribute("component-name", "App");

  const render = () => {
    container.innerHTML = "";
    container.append(Input(filterPosts, state.inputValue));
    container.append(
      Posts(
        state.inputValue ? state.filteredPosts : state.posts,
        state.inputValue
      )
    );
=======
  const searchInput = Input().children[0];
  searchInput.addEventListener('input', debounce(filter, 300));

  container.classList.add("main-container");
  container.setAttribute("component-name", "App");

  function render() {
    container.innerHTML = '';
    container.prepend(searchInput.parentElement);
    if (!state.filteredPosts.length && !searchInput.value) {
      container.append(Posts(state.posts));
      return;
    }
    if (!state.filteredPosts.length && searchInput.value) {
      container.append(NotFound());
    }
    container.append(Posts(state.filteredPosts));
>>>>>>> b38ff99 (posts-project)
  };

  const setPosts = (posts) => {
    state.posts = posts;
    render();
<<<<<<< HEAD
  };

  const setFilteredPosts = (filtered) => {
    state.filteredPosts = filtered;
    render();
  };

  fetchData("/posts").then(setPosts);

  render();

  return container;
};
=======
  }

  fetchData("/posts").then(setPosts);

  const setFilteredPosts = (posts) => {
    state.filteredPosts = posts;
    render();
  }

//  render();

  return container;
};
>>>>>>> b38ff99 (posts-project)
